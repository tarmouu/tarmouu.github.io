{-# LANGUAGE FunctionalDependencies #-}
{-# LANGUAGE FlexibleContexts #-}


module SharedState where

import ConcurMonads


-- Shared memory concurrent monads

class ConcurMnd t => SharedState s t | t -> s where
  get :: t s
  put :: s -> t ()
  stitch :: t x -> t x 

update :: SharedState s t => (s -> s) -> t ()
update f = stitch (get >== \ s -> put (f s))

atomic :: SharedState s t => (x -> t y) -> x -> t y 
atomic k = stitch . k 



-- Coresumptions, residual resumptions

data Cores s y = Cores { coret :: y
                       , cograb :: (s, s -> Cores s y)
                       }

instance Functor (Cores s) where
   fmap f (Cores y (s, k)) = Cores (f y) (s, \ s' -> fmap f (k s'))


instance Comnd (Cores s) where
   eps (Cores y _) = y
   delta c@(Cores _ (s, k)) = Cores c (s, \ s' -> delta (k s'))


copy :: s -> Cores s ()
copy s = Cores () (s, \ s' -> copy s')



-- Some examples

{-
Functions to run the examples on particular shared state concurrent monads
are in Resumptions.hs and BagsOfTraces.hs.
-}

dec :: SharedState Int t => () -> t ()
dec = const get >>> \ s -> put (s - 1)       -- NB! this is not atomic

inc :: SharedState Int t => () -> t ()
inc = const get >>> \ s -> put (s + 1)       -- NB! this is not atomic

reset :: SharedState Int t => () -> t ()
reset = \ () -> put 0

cat :: SharedState String t => String -> () -> t ()

cat w = atomic (const get >>> \ s -> put (s ++ w))
--cat w = \ () -> Grab (\ s -> [(s ++ w, Ret ())])

a :: SharedState String t => () -> t ()
a = cat "a"

b :: SharedState String t => () -> t ()
b = cat "b"

c :: SharedState String t => () -> t ()
c = cat "c"

d :: SharedState String t => () -> t ()
d = cat "d"



r1 :: SharedState String t => t  (((), ()), ())
r1 = ((a ||| b) ||| c) (((), ()), ())

r2 :: SharedState String t => t  ((), ((), ()))
r2 = (a ||| (b ||| c)) ((), ((), ()))

r3 :: SharedState String t => t  ((), ())
r3 = ((a ||| b) >>> (c ||| d)) ((), ())

r4 :: SharedState String t => t  ((), ())
r4 = ((a >>> c) ||| (b >>> d)) ((), ())

r5 :: SharedState String t => t  ((), ())
r5 = atomic ((a ||| b) >>> (c ||| d)) ((), ())

r6 :: SharedState String t => t  ((), ())
r6 = atomic ((a >>> c) ||| (b >>> d)) ((), ())

r7 :: SharedState String t => t  ((), ())
r7 = (atomic (a >>> c) ||| atomic (b >>> d)) ((), ())

