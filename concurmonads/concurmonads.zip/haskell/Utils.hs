{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE FlexibleInstances #-}

module Utils where


-- Void type

data Void

instance Show Void where
  show a = case a of

instance Eq Void where
  a == _ = case a of


-- Order

infix 5 =<

class Ordered a where
  (=<) :: a -> a -> Bool

instance Ordered () where
  () =< () = True

instance (Ordered a, Ordered b) => Ordered (a, b) where
  (x, y) =< (x', y') = x =< x' && y =< y'


-- Ordered functors

{-
class Functor f where
  fmap :: (x -> y) -> f x -> f y
-}

class Functor f => OrderedFunctor f where
  ford :: (x -> x -> Bool) -> (f x -> f x -> Bool)

{-
-- makes sense, but problematic for instance resolution

instance (Ordered x, OrderedFunctor f) => Ordered (f x) where
  (=<) = ford (=<)
-}


-- Listability

class Listable a where
  list :: [a]

instance Listable () where
  list = [()]

instance (Listable a, Listable b) => Listable (a, b) where
  list = [(a, b) | a <- list, b <- list]

instance Listable Void where
  list = []
  
instance Listable Bool where
  list = [False, True]

instance Listable a => Listable (Maybe a) where
  list = Nothing : map Just list

instance (Listable a, Listable b) => Listable (Either a b) where
  list = map Left list ++ map Right list

instance Listable Char where
  list = [' ','a','b','c','d']


bound :: Int
bound = 2

instance Listable a => Listable [a] where
  list = list' bound where
    list' 0 = [[]]
    list' n = [[]] ++ [ a : as | a <- list, as <- list' (n-1) ] 



-- Lists as an ordered functor

{-
instance Functor [] where
  fmap = map
-}

instance OrderedFunctor [] where
  ford (=<) [] []    = True
  ford (=<) [] (_:_) = False
  ford (=<) (_:_) [] = False
  ford (=<) (x:xs) (y:ys) = x =< y && ford (=<) xs ys


-- Bags

newtype Bag a = B { unBag :: [a] } deriving Show 

remove :: Eq a => a ->  [a] -> Maybe [a]
remove x [] = Nothing
remove x (y:ys) = if x == y then Just ys else
                                fmap (y:) (remove x ys)

instance Eq a => Eq (Bag a) where
  B [] == B [] = True
  B [] == _  = False
  B (x:xs) == B ys = case remove x ys of
                       Nothing -> False
                       Just ys' -> B xs == B ys'

instance Eq a => Ordered (Bag a) where
  B [] =< _ = True
  B (x:xs) =< B ys = case remove x ys of
                       Nothing -> False
                       Just ys' -> B xs =< B ys'



instance Listable (Bag String) where
  list = map B [[""],["","a"],["cd","efgh","i"]]
      --,["lmno","","qr","st"],["uv","zbb"]]
      --,["w43","z","t","vxf","","qu"]]



-- Bags as an ordered functor


instance Functor Bag where
  fmap f (B xs) = B (map f xs)

deletions :: [a] -> [(a, [a])]
deletions [] = []
deletions (x:xs) = (x,xs) : [ (y, x:ys)  | (y, ys) <- deletions xs ]

combs :: Int -> [a] -> [[a]]
combs 0 xs = [[]]
combs k [] = []
combs k xs = concat [ map (y:) (combs (k-1) ys) | (y, ys) <- deletions xs ]

instance OrderedFunctor Bag where
  ford leq (B xs) (B ys)
    = or [ and (zipWith leq xs zs) | zs <- combs (length xs) ys ]
