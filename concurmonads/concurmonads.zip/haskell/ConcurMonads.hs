{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE UndecidableInstances #-}

module ConcurMonads where

import Utils
import ConcurMonoids


-- Monads, lax monoidal functors, concurrent monads

class Functor t => Mnd t where
  eta :: x -> t x
  mu :: t (t x) -> t x

klext :: Mnd t => (x -> t y) -> t x -> t y
klext k = mu . fmap k

(>==) :: Mnd t => t x -> (x -> t y) -> t y
c >== k = mu . fmap k $ c

(>>>) :: Mnd t => (x -> t y) -> (y -> t z) -> x -> t z
k >>> l = mu . fmap l . k 


class Functor t => Lmf t where
  psi0 :: t ()
  psi :: t x -> t y -> t (x, y)

jd :: Lmf t => () -> t ()
jd () = psi0

(|||) :: Lmf t => (x -> t z) -> (y -> t w) -> (x, y) -> t (z, w)
(k ||| l) (x, y) = k x  `psi` l y


class (OrderedFunctor t, Mnd t, Lmf t) => ConcurMnd t



-- Writer concurrent monad

{-
This concurrent monad requires a concurrent monoid structure on the
poset of updates.
-}

type Writer m = (,) m

{-
instance Functor (Writer m) where
  fmap f (m, x) = (m, f x)
-}

instance Ordered m => OrderedFunctor (Writer m) where 
  ford (=<.) (m, x) (m', x') = m =< m' && x =<. x' 


instance ConcurMonoid m => Mnd (Writer m) where
  eta x = (idS, x)
  mu (m, (m', x)) = (m >.> m', x)

instance ConcurMonoid m => Lmf (Writer m) where
  psi0 = (idP, ())
  (m, x) `psi` (m', y) = (m <|> m', (x, y))

instance ConcurMonoid m => ConcurMnd (Writer m)


-- Reader concurrent monad

{-
This monad does not assume any structure on the poset of states.
It may be discrete or not.

This concurrent monad is commutative.
-}

type Reader s = (->) s

{-
instance Functor (Reader s) where
  fmap f g = \ s -> f (g s)
-}

instance Listable s =>  OrderedFunctor (Reader s) where
  ford (=<) f g = and [ f s =< g s | s <- list ]

instance Mnd (Reader s) where
  eta x = \ _ -> x
  mu f = \ s -> f s s

instance Lmf (Reader s) where
  psi0 = \ _ -> ()
  f `psi` g = \ s -> (f s, g s)

instance Listable s => ConcurMnd (Reader s)



-- State concurrent monad

{-
Here we need that the poset of states is a lower semilattice.

This concurrent monad is not normal.
-}

class Semilattice s where
  top  :: s
  meet :: s -> s -> s


instance (Eq s, Semilattice s) => Ordered s where
  s1 =< s2 = s1 == s1 `meet` s2


data State s x = S (s -> (s, x))

instance Functor (State s) where
  fmap f (S g) = S (\ s -> let (s', x) = g s in (s', f x))

instance (Eq s, Listable s, Semilattice s) =>
                               OrderedFunctor (State s) where
  ford (=<.) (S f) (S g) = and [helper s | s <- list]
    where helper s = let (s1, x1) = f s in
                     let (s2, x2) = g s in
                     s1 =< s2 && x1 =<. x2

instance Mnd (State s) where
  eta x = S (\ s -> (s, x))
  mu (S g) = S (\ s -> let (s', S f) = g s in f s')

instance Semilattice s => Lmf (State s) where
  psi0 = S (\ _ -> (top, ()))
  psi (S f) (S g) = S (\ s ->
    let (s1, x) = f s in
    let (s2, y) = g s in
    (s1 `meet` s2, (x, y)))

instance (Eq s, Listable s, Semilattice s) => ConcurMnd (State s)




-- Comonads, monad-comonad interaction laws


class Functor d => Comnd d where
  eps :: d y -> y
  delta :: d y -> d (d y)


class (Functor f, Functor g, Mnd r) => FFIL f g r where
  theta :: (f x, g y) -> r (x, y)

class (Mnd t, Comnd d, Mnd r, FFIL t d r) => MCIL t d r




-- Monad maps, lax monoidal functor maps, concurrent monad maps

class (Functor f, Functor g) => Nat f g where
  tau :: f x -> g x

class (Mnd t, Mnd t', Nat t t') => MndMap t t'

class (Lmf t, Lmf t', Nat t t') => LmfMap t t'

class (ConcurMnd t, ConcurMnd t', MndMap t t', LmfMap t t') => ConcurMndMap t t'

