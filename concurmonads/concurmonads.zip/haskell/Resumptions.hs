{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE FlexibleInstances #-}

module Resumptions where

import ConcurMonads
import SharedState
import Utils

-- Resumptions for shared state

data Res s x = Ret x
             | Grab (s -> [(s, Res s x)])


instance Functor (Res s) where
  fmap f (Ret x)  = Ret (f x)
  fmap f (Grab k) = Grab (\ s -> map (\ (s', r) -> (s', fmap f r)) (k s))

instance (Listable s, Eq s) => OrderedFunctor (Res s) where
  ford leq (Ret x0)  (Ret x1)  = leq x0 x1
  ford leq (Ret _)   (Grab _)  = False
  ford leq (Grab _)  (Ret _)   = False
  ford leq (Grab k0) (Grab k1) = and [helper (k0 s) (k1 s) | s <- list] where
     helper []    _  = True
     helper (_:_) [] = False
     helper ((s,r):ps) ((s',r'):ps') =  s == s' && ford leq r r'
                                                    && helper ps ps'
                                        || helper ((s,r):ps) ps'


instance Mnd (Res s) where
  eta x = Ret x
  mu (Ret r)  = r
  mu (Grab k) = Grab (\ s -> map (\ (s', r) -> (s', mu r)) (k s))


{-
-- This is a different monad instance for cooperative instead of
-- preemptive concurrency. Here immediate Ret should be forbidden,
-- else unitality fails. It does not form a concurrent monad. 
-}

{-
instance Mnd (Res s) where
  eta x = Grab (\ s -> [(s, Ret x)])
  mu (Ret r) = r  -- we should not arrive here
  mu (Grab k) = Grab (\ s -> concat (map (\ (s', r) -> mu' (s', r)) (k s)))
     where
       mu' (s', Ret (Ret x))  = [(s', Ret x)]   -- we should not arrive here
       mu' (s', Ret (Grab k)) = k s'
       mu' (s', Grab k) = [(s', mu (Grab k))]

yield :: x -> Res s x
yield x = Grab (\ s -> [(s, Grab (\ s -> [(s, Now x)]))])

(>.=) :: Res s x -> (x -> Res s y) -> Res s y
c >.= k = c >== yield >== k

(>.>) :: (x -> Res s y) -> (y -> Res s z) -> x -> Res s z
k >.> l = k >>> yield >>> l
-}


instance Lmf (Res s) where
  psi0 = Ret ()
  psi r r' = merge r r'

merge :: Res s x -> Res s y -> Res s (x, y)
Ret x `merge` Ret y  = Ret (x, y)
Ret x `merge` Grab l =
   Grab (\ s -> [ (s', Ret x `merge` r) | (s', r) <- l s ])
Grab k `merge` Ret y =
   Grab (\ s -> [ (s', r `merge` Ret y) | (s', r) <- k s ])
Grab k `merge` Grab l =
   Grab (\ s -> [ (s', r `merge` Grab l) | (s', r) <- k s ]
     ++ [ (s', Grab k `merge` r) | (s', r) <- l s ])

instance (Listable s, Eq s) => ConcurMnd (Res s)


-- Shared state operations
 
instance (Listable s, Eq s) => SharedState s (Res s) where
  get = Grab (\ s -> [(s, Ret s)])
  put s = Grab (\ _ -> [(s, Ret ())])
  stitch r = Grab (\ s -> stitchOpt (s, r))
    where stitchOpt :: (s, Res s x) -> [(s, Res s x)]
          stitchOpt (s, Ret x)  = [(s, Ret x)]
          stitchOpt (s, Grab k) = concat (map stitchOpt (k s))



-- Residual resumptions

data RRes s z = RRet z
              | RGrab s [(s, RRes s z)]

instance (Show s, Show x) => Show (RRes s x) where
  show r = show' 0 r where 
      show' n (RRet x)  = "Ret " ++ show x
      show' n (RGrab s srs) = "Grab " ++ show s ++ " > Branch " ++
          let n' = n+2 in concat
                  (map (\ (s', r) -> "\n" ++  replicate n' ' ' ++
                      "Yield " ++ show s' ++ " > " ++ show' n' r) srs)

instance Functor (RRes s) where
  fmap f (RRet z) = RRet (f z)
  fmap f (RGrab s srs) = RGrab s (map (\ (s', r) -> (s', fmap f r)) srs)

instance Eq s => OrderedFunctor (RRes s) where
  ford leq (RRet x0) (RRet x1)   = leq x0 x1
  ford leq (RRet _)  (RGrab _ _) = False
  ford leq (RGrab _ _) (RRet _)  = False
  ford leq (RGrab s ps) (RGrab s' ps') = s == s' && helper ps ps' where
    helper []    _  = True
    helper (_:_) [] = False
    helper ((s,r):ps) ((s',r'):ps') =  s == s' && ford leq r r'
                                               && helper ps ps'
                                    || helper ((s,r):ps) ps'

instance Mnd (RRes s) where
  eta z = RRet z
  mu (RRet r)  = r
  mu (RGrab s srs) = RGrab s (map (\ (s', r) -> (s', mu r)) srs)

instance FFIL (Res s) (Cores s) (RRes s) where
  theta (Ret x, Cores y _) = RRet (x, y)
  theta (Grab k, Cores _ (s, k')) =
         RGrab s (fmap (\ (s', r) -> (s', theta (r, k' s'))) (k s)) 

instance MCIL (Res s) (Cores s) (RRes s)


-- Trees

data Tree z = Lf z
            | Br [Tree z]  deriving Show


instance Functor Tree where
  fmap f (Lf z) = Lf (f z)
  fmap f (Br ts) = Br (map (fmap f) ts)

instance Mnd Tree where
  eta z = Lf z
  mu (Lf t)  = t
  mu (Br ts) = Br (fmap mu ts)

instance FFIL (Res s) (Cores s) Tree where
  theta (Ret x, Cores y _) = Lf (x, y)
  theta (Grab k, Cores _ (s, k')) =
         Br (fmap (\ (s', r) -> theta (r, k' s')) (k s)) 

instance MCIL (Res s) (Cores s) Tree


-- Running

runIsolated :: Res s x -> s -> RRes s x
runIsolated r s = fmap fst $ theta (r, copy s)

{-
-- This does the same.

runIsolated :: Res s x -> s -> RRes s x
runIsolated (Ret x) _ = RRet x
runIsolated (Grab k) s = RGrab s [ (s', runIsolated r s') | (s', r) <- k s]
-}

runShow :: (Show s, Show x) => Res s x -> s -> IO ()
runShow r s = putStrLn . show $ runIsolated r s 

runcmp :: (Eq s, Eq x) => Res s x -> Res s x -> s -> Bool
runcmp r r' s
      = ford (==) (runIsolated r s) (runIsolated r' s)


