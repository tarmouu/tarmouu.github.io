{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE ScopedTypeVariables #-}

module BagsOfTraces where

import ConcurMonads
import SharedState
import Resumptions
import Utils

import Debug.Trace
import Test.QuickCheck


-- Bags of traces

data Trace s x = R x
               | G s s (Trace s x) deriving Show

newtype BoT s x = BoT { unBoT :: Bag (Trace s x) } deriving Show

instance Functor (Trace s) where
  fmap f (R x) = R (f x)
  fmap f (G s s' t) = G s s' (fmap f t) 

instance Functor (BoT s) where
  fmap f (BoT ts) = BoT (fmap (fmap f) ts) where

instance Eq s => OrderedFunctor (Trace s) where
  ford (=<) (R x) (R y) = x =< y
  ford (=<) (R _) (G _ _ _) = False
  ford (=<) (G _ _ _) (R _) = False
  ford (=<) (G s0 s t) (G s0' s' t') = s0 == s0' && s == s' && ford (=<) t t'

instance Eq s => OrderedFunctor (BoT s) where
  ford (=<) (BoT ts) (BoT ts') = ford (ford (=<)) ts ts'

instance Mnd (BoT s) where
  eta x = BoT (B [R x])
  mu (BoT (B ts)) = BoT (B (concat (fmap mu' ts))) where
     mu' (R (BoT (B ts))) = ts
     mu' (G s s' t) = fmap (G s s') (mu' t)

instance Lmf (BoT s) where
  psi0 = BoT (B [R ()])
  BoT (B ts0) `psi` BoT (B ts1) = BoT (B (concat
         [ t0 `shuffle` t1 | t0 <- ts0, t1 <- ts1]))  where

     shuffle :: Trace s x -> Trace s y -> [ Trace s (x, y) ]     
     R x `shuffle` R y = [R (x, y)]
     R x `shuffle` G s s' t = fmap (G s s') (R x `shuffle` t)
     G s s' t `shuffle` R y = fmap (G s s') (t `shuffle` R y)
     G s0 s0' t0 `shuffle` G s1 s1' t1
         = fmap (G s0 s0') (t0 `shuffle` G s1 s1' t1)
         ++ fmap (G s1 s1') (G s0 s0' t0 `shuffle` t1)

instance Eq s => ConcurMnd (BoT s)

instance (Listable s, Eq s) => SharedState s (BoT s) where
  get = BoT (B (fmap (\ s -> G s s (R s)) list))
  put s' = BoT (B (fmap (\ s -> G s s' (R ())) list))

  stitch (BoT (B ts)) =
    BoT (B [ G s s' t' | s <- list, t <- ts, (s', t') <- stitchAcc s t ]) where
      stitchAcc s0 (R x) = [(s0, R x)]
      stitchAcc s0 (G s s' t) = if s0 == s then stitchAcc s' t else []



instance Eq s => FFIL (BoT s) (Cores s) (BoT s) where
  theta (BoT (B ts), c) = BoT (B (concat (map (\ t -> theta' (t, c)) ts))) where
     theta' (R x, Cores y _) = [R (x, y)]
     theta' (G s s' t, Cores _ (s'', k)) =
         if s == s'' then map (G s s') (theta' (t, k s')) else []

instance Eq s => MCIL (BoT s) (Cores s) (BoT s)


-- Running

runIsolatedBoT :: Eq s => BoT s x -> s -> BoT s x
runIsolatedBoT r s = fmap fst $ theta (r, copy s)

runShowBoT :: (Eq s, Show s, Show x) => BoT s x -> s -> IO ()
runShowBoT r s = putStrLn . show $ runIsolatedBoT r s 

runcmpBoT :: (Eq s, Eq x) => BoT s x -> BoT s x -> s -> Bool
runcmpBoT r r' s
      = ford (==) (runIsolatedBoT r s) (runIsolatedBoT r' s)




-- A concurrent monad morphism from resumptions to bags of traces

instance Listable s => Nat (Res s) (BoT s) where
  tau (Ret x) = BoT (B [R x])
  tau (Grab k) = BoT (B [G s s' t | s <- list, (s', r) <- k s,
                                           let BoT (B ts) = tau r, t <- ts ])

instance Listable s => MndMap (Res s) (BoT s)
instance Listable s => LmfMap (Res s) (BoT s)
instance (Listable s, Eq s) => ConcurMndMap (Res s) (BoT s)



-- Testing stuff

type St = Bool

instance (Arbitrary s, Arbitrary x) => Arbitrary (Trace s x) where
  arbitrary =
    do (x :: x) <- arbitrary
       n <- choose (0, 3)
       (l :: [(s, s)]) <- vectorOf n arbitrary
       return (loop x l)
       where loop x [] = R x
             loop x ((s, s') : ss) = G s s' (loop x ss)

instance (Arbitrary s, Arbitrary x) => Arbitrary (BoT s x) where
  arbitrary =
    do n <- choose (0, 3)
       (l :: [Trace s x]) <- vectorOf n arbitrary
       return (BoT (B l))

instance (Eq s, Eq x) => Eq (Trace s x) where
  R x == R y = x == y
  R _ == _ = False
  _ == R _ = False
  (G s0 s0' t0) == (G s1 s1' t1) = s0 == s1 && s0' == s1' && t0 == t1

instance (Eq s, Eq x) => Eq (BoT s x) where
  (BoT (B [])) == (BoT (B [])) = True
  (BoT (B [])) == (BoT (B _)) = False
  (BoT (B (t0 : ts0))) == (BoT (B ts1)) =
    case remove t0 ts1 of
                       Nothing -> False
                       Just ts1' -> BoT (B ts0) == BoT (B ts1')


quickAllwell :: IO ()
quickAllwell =
  quickCheck (\ (f :: BoT St Bool) (g :: BoT St Bool) (h :: BoT St Bool) -> psi f (psi g h) == fmap (\ ((a, b), c) -> (a, (b, c))) (psi (psi f g) h)) >>
  quickCheck (\(f :: BoT St Bool) -> mu (eta f) == f) >>
  quickCheck (\(f :: BoT St Bool) -> mu (fmap eta f) == f) >>
  quickCheck (\(f :: BoT St (BoT St (BoT St Bool))) -> mu (mu f) == mu (fmap mu f)) >>
  return ()
