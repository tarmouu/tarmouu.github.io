Here is the contents of the files:

Utils.hs
  - Void datatype
  - listable types
  
  - ordered sets, ordered functors
  - lists and bags ordered sets
  - lists and bags ordered functors

ConcurMonoids.hs
  - concurrent monoids
  - examples of concurrent monoids

ConcurMonads.hs
  - monads, lax monoidal functors, concurrent monads
  - comonads
  - monad-comonad interaction laws
  - first examples of concurrent monads: writer, reader,  state

SharedState.hs
  - concurrent monads for shared state
  - coresumptions comonad for shared state  
  - example computations in terms of shared state concur monad operations

Resumptions.hs
  - resumptions concurrent monad for shared state
  - functions for running resumptions and comparing results

Resumptions.hs
  - bags-of-traces concurrent monad for shared state
  - functions for running bags-of-traces and comparing results
  - morphism between resumptions and bags-of-traces concurrent monads

