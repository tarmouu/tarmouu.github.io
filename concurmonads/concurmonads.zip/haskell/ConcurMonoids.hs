{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE OverlappingInstances #-}
{-# LANGUAGE ScopedTypeVariables #-}

module ConcurMonoids where

import Utils
import Test.QuickCheck
import System.IO.Unsafe


-- Concurrent monoids


class Ordered a => ConcurMonoid a where
  idS :: a
  (>.>) :: a -> a -> a
  idP :: a
  (<|>) :: a -> a -> a


-- Booleans

{-
Here >.> (disjunction) and <|> (conjunction) are commutative
and idempotent.
-}


instance Ordered Bool where
  False =< True = True
  b =< b' = b == b'

instance ConcurMonoid Bool where
  idS = False
  (>.>) = (||)

  idP = True
  (<|>) = (&&)



-- Lukasiewicz logic

data Luk = F | X | T deriving (Show, Eq)

instance Listable Luk where
  list = [F, X, T]

instance Ordered Luk where
 F =< X = True
 X =< T = True
 F =< T = True
 m =< n = m == n

{-
instance ConcurMonoid Luk where      -- >.>, <|> comm, idemp
 idS = F

 F >.> n = n     -- disj with X >.> X == X
 _ >.> T = T
 m >.> _ = m

 idP = T

 T <|> n = n     -- conj with X <.> X == X
 _ <|> F = F
 m <|> _ = m
-}

instance ConcurMonoid Luk where      -- >.>, <|> comm, non-idemp!
 idS = F

 F >.> n = n     -- disj with X >.> X == T
 X >.> F = X
 _ >.> _ = T

 idP = T

 T <|> n = n     -- conj with X <.> X == F
 X <|> T = X
 _ <|> _ = F




-- A four-valued logic

{-
Here >.> (disjunction) and <|> (conjunction) are both non-commutative
and non-idempotent.
-}


data Four = Bot | L | R | Top deriving (Show, Eq)

instance Listable Four where
  list = [Bot, L, R, Top]

instance Ordered Four where
  Bot =< _ = True
  L =< R = True
  _ =< Top = True
  m =< n = m == n

instance ConcurMonoid Four where
 idS = Bot

 Bot >.> n = n
 m >.> Bot = m
 L >.> n = n
 _ >.> _ = Top

 idP = Top

 Top <|> n = n
 m <|> Top = m
 m <|> R = m
 _ <|> _ = Bot


-- A complicated example

{-
With a == Bool, >.> and <|> are neither commutative nor idempotent.

With a == (), they are commutative, but not idempotent.

With a == Void, they are also idempotent.
-}


instance Eq a => Ordered (Maybe (Bool, [a])) where 
  Just (False, []) =< Just (True, [])  = True
  Just (False, _:_) =< Nothing = True
  Nothing =< Just (True, _:_)  = True
  Just (False, _:_) =< Just (True, _:_) = True
  m =< n = m == n
  
instance Eq a => ConcurMonoid (Maybe (Bool, [a])) where
  idS = Just (False, [])

  Just (False, []) >.> m = m
  m >.> Just (False, []) = m
  Just (False, as) >.> Just (False, bs) = Just (False, as ++ bs)
  Just (True, []) >.> m = m
  m >.> Just (True, []) = m
  _ >.> _ = Nothing

  idP = Just (True, [])

  Just (True, []) <|> m = m
  m <|> Just (True, []) = m
  Just (True, as)  <|> Just (True, bs)  = Just (True, as ++ bs)
  Just (False, []) <|> m = m
  m <|> Just (False, []) = m
  _ <|> _ = Nothing

{-
Rough idea:

(False, Just as) -- sequence of as
(False, Nothing) -- notriv sequence (contains idP or parallel)

(True,  Just as) -- parallel of as
(True,  Nothing) -- notriv parallel (contains idS or sequence)
-}



-- Synchronization trees


data Tree a = Lf | Br [(a, Tree a)]  deriving Eq

-- Lf is a is successful terminated computation

-- Br [] is a stuck computation;
-- in principle we could restrict Br to nonempty lists

{-
bound = 2

instance Listable a => Listable (Tree a) where
  list = list' bound where
    list' 0 = [Lf]
    list' n = [Lf] ++ [ Br [(a,r)] | a <- list, r <- list' (n-1) ]
                    ++ [ Br [(a,r),(a',r')] | a <- list, r <- list' (n-1),
                                              a' <- list, r' <- list' (n-1)]
-}

instance Listable (Tree Int) where
  list = [Lf, Br [(0,Lf)], Br [(1,Lf),(2,Lf)],
          Br [(3, Br [(4,Lf),(5,Lf)]), (6,Lf)],
          Br [(7,Lf), (8, Br []), (9, Br [(10, Br [(11,Lf)]), (12,Lf)])],
          Br [(13, Br []), (14,Lf), (15, Br [(16,Lf), (17,Lf)]), (18, Lf)]
         ]

instance Eq a => Ordered (Tree a) where
  Lf =< Lf = True
  Lf =< Br _ = False
  Br _ =< Lf = False
  Br ars =< Br ars' = helper ars ars' where
    helper [] _ = True
    helper (_:_) [] = False
    helper ((a,r):ars) ((a',r'):ars') = a == a' && r =< r'
                                               && helper ars ars'
                                     || helper ((a,r):ars) ars'

instance Eq a => ConcurMonoid (Tree a) where
  idS = Lf

  Lf >.> r' = r'
  Br ars >.> r' = Br (map (\ (a, r) -> (a, r >.> r')) ars)

  idP = Lf

  Lf <|> r' = r'
  r <|> Lf = r
  Br ars <|> Br ars' =
     Br ( map (\ (a, r) -> (a, r <|> Br ars')) ars
       ++ map (\ (a', r') -> (a', Br ars <|> r')) ars' )



-- Bags of traces 

type BoT a = Bag [a]

instance Eq a => Ordered (BoT a) where
  B [] =< _ = True
  B (xs:xss) =< B yss = case remove xs yss of
                          Nothing -> False
                          Just yss' -> B xss =< B yss

instance Eq a => ConcurMonoid (BoT a) where
  idS = B [[]]

  B xss >.> B yss = B [ xs ++ ys | xs <- xss, ys <- yss ]

  idP = B [[]]

  B xss <|> B yss = B (concat [ shuffle xs ys | xs <- xss, ys <- yss ]) where
    shuffle :: [a] -> [a] -> [[a]]
    shuffle [] yss = [yss] 
    shuffle xss [] = [xss] 
    shuffle (x:xs) (y:ys) = map (x:) (shuffle xs (y:ys))
                       ++ map (y:) (shuffle (x:xs) ys)


-- Verification/testing

-- Try alternatives here

type Action = Bool
--type Action = ()
--type Action = Void

--type CM = Maybe (Bool, [Action])

--type CM = Bool

--type CM = Luk

--type CM = Four

--type CM = Tree Int

type CM = Bag String


valid1 p = and [ p m | m <- list :: [CM]]

counterex1 p = [ m | m <- list :: [CM], not (p m)]

valid2 p = and [ p m n | m <- list :: [CM], n <- list ]

counterex2 p = [ (m, n) | m <- list :: [CM], n <- list, not (p m n) ]


valid3 p = let l = list :: [CM] in and [ p m n o | m <- l, n <- l, o <- l ]

counterex3 p = [ (m, n, o) | m <- list :: [CM], n <- list, o <- list, not (p m n o) ]

valid4 p = and [ p k l m n | k <- list :: [CM], l <- list, m <- list, n <- list]

counterex4 p = [ (k, l, m, n) | k <- list :: [CM], l <- list, m <- list, n <- list, not (p k l m n) ]


lunitS m = idS >.> m == m
runitS m = m == m >.> idS
assocS m n o = (m >.> n) >.> o == m >.> (n >.> o)

lunitP m = idP <|> m == m
runitP m = m == m <|> idP
assocP m n o =  (m <|> n) <|> o == m <|> (n <|> o)

ineq1 =  idS =< (idP :: CM)
ineq2 = idP >.> idP =< (idP :: CM)
ineq3 = (idS :: CM) =< idS <|> idS
ineq4 k l m n = (k <|> l) >.> (m <|> n) =< (k >.> m) <|> (l >.> n)

monotS m m' n n' = (m =< m' && n =< n') <= m >.> n =< m' >.> n'
monotP m m' n n' = (m =< m' && n =< n') <= m <|> n =< m' <|> n'

refl m =  m =< m
trans m n o = (m =< n && n =< o) <= (m =< o)
antisymm m n =  (m =< n && n =< m) <= (m == n)

allwell = valid1 lunitS && valid1 runitS && valid3 assocS && valid4 monotS
       && valid1 lunitP && valid1 runitP && valid3 assocP && valid4 monotP
       && ineq1 && ineq2 && ineq3 && valid4 ineq4
       && valid1 refl && valid3 trans && valid2 antisymm


eq1 = idS == (idP :: CM)
eq4 k l m n = (k <|> l) >.> (m <|> n) == (k >.> m) <|> (l >.> n)

idempS m = m >.> m == m
idempP m = m <|> m == m

commS m n = m >.> n == n >.> m
commP m n =  m <|> n == n <|> m

proper =
   not (eq1 || valid4 eq4
        || valid1 idempS || valid1 idempP
        || valid2 commS || valid2 commP
       )


instance Arbitrary a => Arbitrary (Bag a) where
  arbitrary = do (l :: [a]) <- arbitrary
                 return (B l)

quickAllwell :: IO ()
quickAllwell =
  valid1 lunitS >> valid1 runitS >> valid3 assocS >> valid4 monotS
       >> valid1 lunitP >> valid1 runitP >> valid3 assocP >> valid4 monotP
       >> valid4 ineq4
       >> valid1 refl >> valid3 trans >> valid2 antisymm >> return ()
  where
    valid1 (p :: CM -> Bool) = quickCheck p
    valid2 (p :: CM -> CM -> Bool) = quickCheck p
    valid3 (p :: CM -> CM -> CM -> Bool) = quickCheck p
    valid4 (p :: CM -> CM -> CM -> CM -> Bool) = quickCheck p

